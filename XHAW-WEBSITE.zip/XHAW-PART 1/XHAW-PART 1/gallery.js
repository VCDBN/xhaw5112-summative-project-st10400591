document.addEventListener("DOMContentLoaded", function () {
  let slideIndex = 0;

  function showSlides() {
      const slides = document.querySelectorAll(".slide");
      
      // Hide all slides
      slides.forEach(slide => {
          slide.style.display = "none";
      });

      // Increment the slide index and reset if necessary
      slideIndex++;
      if (slideIndex > slides.length) {
          slideIndex = 1;
      }

      // Display the current slide
      slides[slideIndex - 1].style.display = "block";

      // Automatically change slides every 3 seconds (3000 milliseconds)
      setTimeout(showSlides, 3000);
  }

  // Start the slideshow
  showSlides();
});
