document.addEventListener("DOMContentLoaded", function () {
    // Get references to form elements
    const coursesSelect = document.getElementById("courses");
    const totalAmount = document.getElementById("total-amount");
    const calculateButton = document.getElementById("calculate-button");

    // Function to calculate the total fee
    function calculateTotalFee() {
        const selectedCourses = Array.from(coursesSelect.selectedOptions);

        let totalFee = 0;
        selectedCourses.forEach(course => {
            const feeMatch = course.textContent.match(/\d+/); // Extract the fee from the course text
            if (feeMatch) {
                totalFee += parseInt(feeMatch[0]);
            }
        });

        // Display the total fee
        totalAmount.textContent = "Total Fee: R" + totalFee;
    }

    // Event listener for the Calculate Total Fee button
    calculateButton.addEventListener("click", calculateTotalFee);

    // Prevent form submission (for demonstration purposes)
    const courseForm = document.getElementById("course-form");
    courseForm.addEventListener("submit", (e) => {
        e.preventDefault();
        // In a real implementation, you would handle the form submission (e.g., send data to a server).
        // For now, we prevent the default behavior to demonstrate the calculation.
    });
});

