document.addEventListener("DOMContentLoaded", function () {
    // Get references to form elements
    const shortCoursesSelect = document.getElementById("short-courses");
    const shortTotalAmount = document.getElementById("short-total-amount");
    const shortCalculateButton = document.getElementById("short-calculate-button");
    const shortCourseForm = document.getElementById("short-course-form");

    // Function to calculate the total fee for short courses
    function calculateShortTotalFee() {
        const selectedShortCourses = Array.from(shortCoursesSelect.selectedOptions);

        let shortTotalFee = 0;
        selectedShortCourses.forEach(course => {
            const feeMatch = course.textContent.match(/\d+/); // Extract the fee from the course text
            if (feeMatch) {
                shortTotalFee += parseInt(feeMatch[0]);
            }
        });

        // Display the total fee for short courses
        shortTotalAmount.textContent = "Total Fee: R" + shortTotalFee;
    }

    // Event listener for the Calculate Total Fee button for short courses
    shortCalculateButton.addEventListener("click", calculateShortTotalFee);

    // Prevent form submission for short courses (for demonstration purposes)
    shortCourseForm.addEventListener("submit", (e) => {
        e.preventDefault();
        // In a real implementation, you would handle the form submission (e.g., send data to a server).
        // For now, we prevent the default behavior to demonstrate the calculation.
    });
});
