import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';

const Header = () => {
  return (
    <View style={styles.header}>
      <Image source={require('./Logo/EmpoweringTheNation.jpg')} style={styles.logo} />
      <Text style={styles.headerTitle}>Cooking</Text>
    </View>
  );
};

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text>&copy; 2023 Empowering the Nation</Text>
    </View>
  );
};

const App = () => {
  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.courseContent}>
        <Text style={styles.courseTitle}>Cooking Course</Text>
        <Text style={styles.courseDescription}>
          <Text style={styles.strongText}>Fees:</Text> R750
        </Text>
        <Text style={styles.courseDescription}>
          <Text style={styles.strongText}>Purpose:</Text> Our Cooking course is a culinary journey where participants will master the art of preparing nutritious family meals. This course covers a wide range of topics, including understanding nutritional requirements for a healthy body, identifying various types of protein, carbohydrates, and vegetables, and planning balanced meals. Participants will also gain hands-on experience in meal preparation and cooking techniques. Whether you're a novice in the kitchen or looking to expand your cooking skills, this course will help you create delicious and healthy dishes for yourself and your family.
        </Text>
      </ScrollView>
      <ScrollView style={styles.slideshowContainer}>
        {/* Implement your slideshow component here */}
      </ScrollView>
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: 'blue',
    alignItems: 'center',
    padding: 10,
  },
  logo: {
    width: 100, // Adjust the dimensions as needed
    height: 100, // Adjust the dimensions as needed
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
  },
  courseContent: {
    padding: 10,
  },
  courseTitle: {
    fontSize: 18,
  },
  courseDescription: {
    // Styles for the course description
  },
  strongText: {
    fontWeight: 'bold',
  },
  slideshowContainer: {
    // Styles for slideshow
  },
  footer: {
    backgroundColor: 'grey',
    padding: 10,
    alignItems: 'center',
  },
});

export default App;
