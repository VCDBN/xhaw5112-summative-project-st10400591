import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';

const Header = () => {
  return (
    <View style={styles.header}>
      <Image source={require('./Logo/EmpoweringTheNation.jpg')} style={styles.logo} />
      <Text style={styles.headerTitle}>Sewing</Text>
    </View>
  );
};

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text>&copy; 2023 Empowering the Nation</Text>
    </View>
  );
};

const App = () => {
  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.courseContent}>
        <Text style={styles.courseTitle}>Sewing Course</Text>
        <Text style={styles.courseDescription}>
          <Text style={styles.strongText}>Purpose:</Text> Our Sewing course is perfect for those who want to explore the world of fashion and garment design. Participants will discover the art of sewing, including mastering various types of stitches, threading a sewing machine, sewing buttons, zips, hems, and seams. Whether you're a beginner or looking to refine your sewing skills, this course is tailored to help you create and alter garments with confidence.
        </Text>
      </ScrollView>
      <ScrollView style={styles.slideshowContainer}>
        {/* Implement your slideshow component here */}
      </ScrollView>
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: 'blue',
    alignItems: 'center',
    padding: 10,
  },
  logo: {
    width: 100, // Adjust the dimensions as needed
    height: 100, // Adjust the dimensions as needed
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
  },
  courseContent: {
    padding: 10,
  },
  courseTitle: {
    fontSize: 18,
  },
  courseDescription: {
    // Styles for the course description
  },
  strongText: {
    fontWeight: 'bold',
  },
  slideshowContainer: {
    // Styles for slideshow
  },
  footer: {
    backgroundColor: 'grey',
    padding: 10,
    alignItems: 'center',
  },
});

export default App;
