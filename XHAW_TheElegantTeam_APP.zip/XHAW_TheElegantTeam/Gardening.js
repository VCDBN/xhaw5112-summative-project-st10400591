import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';

const Header = () => {
  return (
    <View style={styles.header}>
      <Image source={require('./Logo/EmpoweringTheNation.jpg')} style={styles.logo} />
      <Text style={styles.headerTitle}>Garden Maintenance</Text>
    </View>
  );
};

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text>&copy; 2023 Empowering the Nation</Text>
    </View>
  );
};

const App = () => {
  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.courseContent}>
        <Text style={styles.courseTitle}>Garden Maintenance Course</Text>
        <Text style={styles.courseDescription}>
          <Text style={styles.strongText}>Fees:</Text> R750
        </Text>
        <Text style={styles.courseDescription}>
          <Text style={styles.strongText}>Purpose:</Text> Our Garden Maintenance course is designed for those with a green thumb or anyone interested in enhancing their gardening skills. Participants will explore the art of garden maintenance, learning about water restrictions and the watering requirements of indigenous and exotic plants. The course covers essential topics such as pruning and propagation of plants, planting techniques for different plant types, and overall garden care. By the end of this course, you'll have the knowledge and skills needed to create and maintain a beautiful domestic garden.
        </Text>
      </ScrollView>
      <ScrollView style={styles.slideshowContainer}>
        {/* Implement your slideshow component here */}
      </ScrollView>
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: 'blue',
    alignItems: 'center',
    padding: 10,
  },
  logo: {
    width: 100, // Adjust the dimensions as needed
    height: 100, // Adjust the dimensions as needed
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
  },
  courseContent: {
    padding: 10,
  },
  courseTitle: {
    fontSize: 18,
  },
  courseDescription: {
    // Styles for the course description
  },
  strongText: {
    fontWeight: 'bold',
  },
  slideshowContainer: {
    // Styles for slideshow
  },
  footer: {
    backgroundColor: 'grey',
    padding: 10,
    alignItems: 'center',
  },
});

export default App;
