import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TextInput, TouchableOpacity } from 'react-native';

const Header = () => {
  return (
    <View style={styles.header}>
      <Image source={require('./Logo/EmpoweringTheNation.jpg')} style={styles.logo} />
      <Text style={styles.headerTitle}>Contact Us</Text>
    </View>
  );
};

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text>&copy; 2023 Empowering the Nation</Text>
    </View>
  );
};

const App = () => {
  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.contactContainer}>
        <Text style={styles.contactTitle}>Contact Us</Text>
        <View style={styles.contactForm}>
          <TextInput style={styles.input} placeholder="Name" />
          <TextInput style={styles.input} placeholder="Email" />
          <TextInput
            style={styles.textarea}
            placeholder="Message"
            multiline={true}
            numberOfLines={4}
          />
          <TouchableOpacity style={styles.submitBtn}>
            <Text>Submit</Text>
          </TouchableOpacity>
        </View>
        <Text>For inquiries and bookings, please feel free to contact us:</Text>
        <Text>Phone: <Text style={styles.contactLink} onPress={() => dialPhoneNumber('+27611469563')}>+27 61146 9563</Text></Text>
        <Text>Email: <Text style={styles.contactLink} onPress={() => sendEmail('empoweringthenation@gmail.com')}>empoweringthenation@gmail.com</Text></Text>
        <Text>Addresses: 123 Main Street, Johannesburg - 687 Musgrave Rd, Durban - Uvongo Street, Port Shepstone</Text>
      </ScrollView>
      <Footer />
    </View>
  );
};

const dialPhoneNumber = (phoneNumber) => {
  // Implement phone dialing logic
};

const sendEmail = (emailAddress) => {
  // Implement email sending logic
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: 'blue',
    alignItems: 'center',
    padding: 10,
  },
  logo: {
    width: 100, // Adjust the dimensions as needed
    height: 100, // Adjust the dimensions as needed
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
  },
  contactContainer: {
    padding: 10,
  },
  contactTitle: {
    fontSize: 18,
  },
  contactForm: {
    // Styles for the contact form
  },
  input: {
    borderColor: 'gray',
    borderWidth: 1,
    padding: 5,
    marginBottom: 10,
  },
  textarea: {
    borderColor: 'gray',
    borderWidth: 1,
    padding: 5,
    marginBottom: 10,
    height: 100,
  },
  submitBtn: {
    backgroundColor: 'blue',
    padding: 10,
    alignItems: 'center',
  },
  contactLink: {
    color: 'blue',
    textDecorationLine: 'underline',
  },
  footer: {
    backgroundColor: 'grey',
    padding: 10,
    alignItems: 'center',
  },
});

export default App;
