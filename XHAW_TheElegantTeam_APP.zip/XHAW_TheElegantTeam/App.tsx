import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
       
        <View style={styles.headerContent}>
          <View style={styles.linksContainer}>
            <TouchableOpacity onPress={() => navigateToScreen('Screen1')}>
              <Text style={styles.link}>Home</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigateToScreen('Screen2')}>
              <Text style={styles.link}>Six-Month Course</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigateToScreen('Screen3')}>
              <Text style={styles.link}>Short Course</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigateToScreen('Screen4')}>
              <Text style={styles.link}>Contact</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.headerText}>
            <Text style={styles.companyName}>Empowering The Nation</Text>
            <Text style={styles.slogan}>Empowering Domestic Workers and Gardeners through Skills Training</Text>
          </View>
        </View>
      </View>
      <ScrollView style={styles.content}>
        <Slideshow />
        <AdditionalInfo />
      </ScrollView>
      <Footer />
    </View>
  );
};

const navigateToScreen = (screenName) => {
  // Implement navigation logic to go to the selected screen
};

const Slideshow = () => {
  return (
    <View style={styles.slideshowContainer}>
      {/* Place your slideshow component here */}
    </View>
  );
};

const AdditionalInfo = () => {
  return (
    <View style={styles.additionalInfoContainer}>
      <Text>Additional Information:</Text>
      <Text>
        This is additional information that you can include below the slideshow. You can
        customize this text as needed.
      </Text>
    </View>
  );
};

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text>@ 2023 Empowering the Nation</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  header: {
    backgroundColor: 'blue',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
  },
  logo: {
    width: 100, // Adjust the dimensions as needed
    height: 100, // Adjust the dimensions as needed
  },
  headerContent: {
    flex: 1,
    flexDirection: 'column',
  },
  linksContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  link: {
    color: 'white',
    fontSize: 16,
    marginHorizontal: 10,
  },
  headerText: {
    alignItems: 'center',
  },
  companyName: {
    color: 'white',
    fontSize: 20,
  },
  slogan: {
    color: 'white',
    fontSize: 16,
  },
  content: {
    flex: 1,
    padding: 10,
  },
  slideshowContainer: {
    // Styles for slideshow
  },
  additionalInfoContainer: {
    padding: 10,
  },
  footer: {
    backgroundColor: 'grey',
    padding: 10,
    alignItems: 'center',
  },
});

export default App;
